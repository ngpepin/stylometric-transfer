# KEY CHARACTERISTICS OF AN IT ARCHITECTURE SUPPORTING MASS-CUSTOMIZATION SERVICE A STRATEGY: A CASE STUDY

BY Nicolas H. Pepin

A MANAGEMENT RESEARCH PROJECT

PRESENTED TO DR. BRENT GALLUPE QUEEN'S UNIVERSITY SCHOOL OF BUSINESS

IN CONFORMANCE WITH THE REQUIREMENTS OF AN EXECUTIVE MASTER OF BUSINESS ADMINISTRATION

APRIL 1997

## SECTION 1: PURPOSE & SCOPE

This Management Research Project (MRP) tackles two main themes, one strategic, one practical. As the reader will soon see, these two themes exist in a synergistic relationship; each complementing the other.

### STRATEGIC THEME

The implications on IT architecting of recent changes in thinking in the management literature which advocates moving away from the traditional, static concept of strategy to a more dynamic concept of strategy as 'sensing and responding' <sup>66</sup> are examined.

- The old strategic paradigm emphasized the importance of senior managers investing significant up-front effort in performing detailed industry analysis, long-term forecasting; highly rational, structured, and bureaucratic budget-driven planning processes, etc. This effort led to the development of mechanistic strategies built around generic industrial-economic models which were subsequently implemented by unquestioning employees.
- The new paradigm of business strategy emphasizes the importance of building flexible organizations, business processes, and information resources which permit empowered teams to effectively and profitably respond to fast-paced value shifts and discontinuities in the markets they serve.

Flexibility is particularly important in service industries, where the nature of a service offering is only fully defined at the time of interaction between the service provider and customer. Thus, while the application in advance of such traditional tools as cluster analysis for identifying market segments, and statistical sampling and focus groups for establishing customer quality profiles can be very useful in defining the general class of customers to be served, it is important to recognize that significant

The act of developing IT architectures. 2 Stephan H. Haeckel, Adaptive enterprise design: The sense-and-respond model, Planning Review v23n3 May/Jun 1995. pp. 6-13. <sup>3</sup>

Barry Sheehy, Hyler Bracey, Rick Frazier, Winning the Race for Value: Strategies to Create Competitive Advantage Emerging "Age of Abundance" (Toronto: Amacom; 1996), pp. 86-103. in the

<sup>4</sup> Frank W. Davis and Karl B. Manrodt; Customer Responsive Management: The Flexible Advantage (Cambridge; Massachusetts: Blackwell, 1996), pp. 27-50.

quality gaps will always exist between the needs of real, live customers and benefits provided by statistically formulated segment-targeted service products or product lines (see fig. 1). Excellence in service provision depends on the delivery of what Leonard Berry calls the 'service surprise'—customer expectations (based on their common experience with service encounters). This feat demands an organizational culture and structure already in place which is customer-responsive and which enables real-time strategizing by front-line employees whose interaction with customers may be the only experience those customers have of the organization.

From a management and IT architecture perspective, the distinction between the old and new paradigms is fundamentally the difference between controlling and empowering.

Figure 1: A conventional two-market-segment offering results in varying sizes of quality gaps for actual customers 1, 2 and 3. Flexible response would allow offerings to be customized in real time to narrow or eliminate these gaps [Source: adapted from Davis & Manrodt; Op. Cit., p. 54 (figure 3.2).]

The IT architecture no longer serves to enforce a strictly bounded set of programmed behaviours within a hierarchical command-and-control management structure, but instead empowers, within a new 'inverted' or upside-down pyramid corporate structure, properly trained and acculturated customer contact employees with the information and tools to lead in the translation of management's vision and broad business objectives into real customer value.

Employees are no longer strictly held to narrowly-defined financial and accounting measures of 'tangibles' such as sales volume, market share, profits and losses; rates of return; and contribution levels, but are also motivated and rewarded in their pursuit of 'soft' performance indicators which directly influence the perception and experience of quality by customers. Profitability is expected to mirror these efforts at building customer and employee loyalty—the former resulting in a steady stream of recurring revenue whose discounted present value—not just the present transaction—represents the customer's real value to the firm.<sup>2</sup>

Unfortunately, many companies' information systems have not been designed with this kind of flexible response capability in mind. The optimum system would be a fast-acting database system with the contact person able (1) to move easily from one specialized data source to another and (2) to mix and match data in an optimum fashion for each customer. For historical reasons, companies have usually developed their internal systems separately around their old organizational configurations and around computer architectures that are more suitable for calculations than for database call-ups <sup>12</sup> and comparisons.

We would add to James Quinn's preceding comment that not only is it necessary to permit fast and easy access, mixing and matching of customer data, but that it is also crucial to empower the contact people with the ability to mix and match processes and process components to in fact customize the way the service is performed to respond to the diagnostic these front-line employees have made of what particular customers really want (a diagnostic aided by the ready access by the contact employees of data collected from past interactions with individual customers). Only if customer contact employees are thus empowered with both the knowledge and the means to apply that knowledge to a specific context of an encounter, will habitual narrowing of the quality gap be truly possible and feasible.

MANAGEMENT RESEARCH PROJECT N. H. PEPIN (239 9976) PAGE 7

James Brian Quinn, Intelligent Enterprise: A Knowledge and Service Based Paradigm for Industry (New York: Free Press, 1992), p. 129-132. <sup>10</sup>

Frederick F. Reichheld, The Loyalty Effect: The Hidden Force Behind Growth, Profits, and Lasting Value (Boston, Massachusetts; 1996) <sup>11</sup>

Thomas A. Stewart, Intellectual Capital: The New Wealth of Organizations (Toronto: Doubleday Currency;

<sup>1997),</sup> pp. 142-165, pp. 240-246. <sup>12</sup>James Brian Quinn, Op. Cit., p. 133-124.

### PRACTICAL THEME

The major practical theme of this report is to develop an IT architecture for Industry Canada's Spectrum Management Program (SMP). This major government program is facing a breakpoint in its business environment which the old strategic paradigm cannot satisfactorily address. The organization is under severe pressure to deliver on six 'value drivers'—so named because each has a significant impact on the value <sup>66</sup> the organization provides to its thousands of customers. These value drivers are: continuity/recovery capabilities; trust (and loyalty) building; quality and cost control; employee empowerment; fast cycle time; and flexibility and responsiveness.

Perhaps the most important (or at least, the most urgent) of these is continuity/recovery. As will be seen, the SMP has been provided with funding by a central agency of the federal government to put together a Business Continuity and Recovery Plan (BC&RP) with which to address organizational and infrastructural deficiencies signaled by several recent service disruptions. It is hoped that this funding can leverage the development of an IT architecture that will help deal with these deficiencies, and the accountabilities created under the funding, while also providing a strategic framework for addressing the other value drivers. Section 2 describes the SMP's business environment in detail, elaborates on the need for a BC&RP, and indicates how the other value drivers were identified.

Figure 2, below, provides a comprehensive map of the arguments and conceptual relationships presented in this paper. We have already briefly discussed some initial aspects of the arguments flowing from the right-most box, the Strategic Theme. The red diamonds emerging from the left-most box, the Practical Theme, represent the value drivers listed above. These value drivers are the pillars of SMP's strategy for responding—even taking advantage of—the breakpoint, or discontinuity, taking place in its business environment. They also dictate what the IT architecture must deliver on to be deemed a success (i.e., they are fundamental key success factors, or KSFs), a difficult task given that conventional analysis would conclude that many were irreconcilable.

This paper seeks to think 'outside the box,' taking full advantage of new ideas in strategy, service quality, customer value, business modeling, and object-oriented technology to turn conventional wisdom on its head and find an innovative yet realistic path to excellence for the program.

Because the scope of this paper is ambitious, some sub-topics will be treated with less than the depth they really deserve. The purpose of this paper, however, is to point in a promising direction and to stimulate thought, debate, and research among managers and employees at the SMP, not to present all of the answers in cookbook detail. It is expected that several lines of research and development will emerge at the SMP as a result of this paper, and that the gaps and ambiguities identified or passed over by this paper will be subjected to the scrutiny and formidable creativity of SMP employees at all levels.

### ARGUMENT FLOW AND LOGIC

Let us conclude this introduction by briefly outlining the logic of this paper, as illustrated in fig. 2

- The New Strategic Paradigm. The old strategic paradigm of planning, forecasting and generic strategies is rejected in favour of 'sense and respond' <sup>66</sup>—a mass-customization view of strategy. This lays the intellectual foundations for the rest of the paper.
- Re-Framing BC&RP. Dissatisfaction with the current approach to Business Continuity and Recovery Planning (BC&RP) with its emphasis on the conventional tools of prediction, exhaustive plan and policy development, narrow cost accounting, and a view of customer value limited to one-off transactions is described within the context of our argument about a paradigm shift in strategic thinking under 1. (above). BC&RP is reframed to fit the new strategic paradigm: it is shown to be essentially a sub-set of quality, and characterized in terms of customer trust and loyalty, process criticality, total profit potential of customers, and interruption elasticity of present and future demand (all terms are defined in the body of this paper).
- Building a Model of the Enterprise. By re-framing conventional BC&RP, the value drivers of continuity/recovery, trust, and quality/cost are shown to be united under one process- and value-oriented model of the enterprise.
- Executing the Enterprise Model. The enterprise model is expanded and the characteristics of a model-driven enterprise engine described that incorporate the additional value drivers of flexibility/responsiveness and empowerment. The notions of mass-customization are re-visited within the context of this model; service recovery is shown to be a sub-set of service customization.
- Real-Time Customization of the Enterprise Model. Important considerations are presented regarding providing aspects of the KSFs and responding to the fast cycle-time value driver. Some pitfalls of group decision-making under time pressure are described, and possible GDSS solutions briefly presented.
- Implementing the Enterprise Engine. Implementation options are considered. Business modeling schemes are compared and contrasted. Workflow technology is considered and critiqued. The use of Object Oriented Business Modeling ('Business Engineering' as it is termed by some) is discussed and advantages highlighted. The development methodology and the roles of users and SMP's IS group in developing and implementing are also discussed.
- Key Success Factors & Recommendations: Builds recommendations for this project are provided.

Implicit in the above argument flow is the author's belief that the best way of tackling the integration of the many value drivers facing the SMP is to proceed with the development of a comprehensive *enterprise model*.

Figure 3: The Möbius Strip analogy of value driver interrelationships. An increase in relative quality and customization results in a movement upward and a 'service surprise'—greater customer value; and consequently, greater trust. A decline in quality (due, for instance, to a service disruption) moves in a downward direction, resulting in diminished value, and thus eroded trust. Only a considerable recovery effort can hope to circle the Möbius Strip's single surface to eventually rejoin the upper area signifying high value and trust. Note that the recovery route to trust is much longer and circuitous, however, than the direct path. [Source: Author.]

Modeling, it will be shown, provides the organization with the insights it needs to optimize its operations around the six value drivers. It provides a way of dynamically collecting data and measuring performance with respect to how processes interact to best deliver customer value, build trust and loyalty, and how customer value is affected by service interruptions on one hand, and by service quality and customization on the other (see Fig. 3)

Our objective is thus to arrive at a short-list of characteristics such a model must possess in order to empower front-line employees with the information and tools they need to make service recovery and customization decisions that will build customer value and loyalty while also contributing to profitability.

One of these characteristics can be stated a priori: because both recovery and customization decisions must be made rapidly and in consultation with functional experts, the language or visual representation used to provide employees with information on the enterprise model must be easy to work with and must lend itself to a group decision-making situation under considerable time pressure. Our brief discussion of GDSS consequently focuses in on the advantages and pitfalls associated with using computer mediation to attempt to accelerate group decision speed while maintaining or improving decision quality.

# SECTION 2: THE BUSINESS CONTEXT

The Spectrum Management Program (SMP) is recognized as one of the most complex and mission-critical services delivered under the mandate of the federal Minister of Industry. The Program is responsible for coordinating the use of the radio spectrum by millions of Canadian users employing an installed base of over $15 billion in radiotelecommunications equipment and facilities; ranging from cellular telephones, CB radios, aircraft radio, and wireless LANs to public radio bands and television broadcasters, microwave transmitters and satellite base stations. This coordination has required large investments in Information Technology (IT), similar in scope and magnitude to those undertaken by other departments in conducting such activities as Air Traffic Control (ATC) operations or Ports Management.

In this Section, the author examines the key issues currently facing SMP management, and ends this examination with a brief and preliminary mini case analysis <sup>66</sup> summarizing pertinent organizational strengths and weaknesses, environmental threats and opportunities, and key success factors (KSFs) which, in addition to subsequent analysis, served to drive the design of the information architecture detailed later in this report.

## 2.1 Concerns Mount Over Reliability and Business Continuity

The need for reliability and business continuity and recovery must figure prominently in the SMP's IT investment decisions. The SMP's role in controlling radio spectrum use, tracing and resolving interference problems, establishing in real time emergency communications arrangements and disaster relief, developing contingency traffic routings, planning spectrum allocations for the growing rush to market of new wireless products with steep development costs and narrow profitability windows, managing conflicts in international spectrum uses, etc., requires quick and constant response, often tailored to circumstances which give every service request an element of uniqueness. The Program has found the challenge of meeting reliability and continuity standards difficult, particularly given the explosive growth in uses being found for the spectrum.

In practice, the SMP's operations and information infrastructure have evolved in accordance with short-term needs, industry fads, and above all with no particular vision of the whole (see Fig. 4). Investment decisions have been made by IS and by business units, with no formal or consistent consultation or coordination taking place. Indeed, if we define the concept of an information architecture as "the policies and guidelines that govern the arrangement of IT tools and data... establishing a logical, coherent plan; ensuring that decisions about technology investment and use are in keeping with corporate strategy and capabilities," the SMP has no IT architecture at all. Rather, it has a complex and highly temperamental mix of Ethernet LANs and WANs, secure fault-tolerant LAN networks, networked monitoring devices, HF and VHF Radio Systems, large monitoring, tracking and financial databases, GIS systems and graphical workstations, econometric modeling systems, administrative workstations, order processing and billing systems, fault-tolerant emergency field units (including MSAT voice transceivers and hardened notebook computers loaded with GPS equipment and wireless DirectPC TCP/IP & Ethernet units), High Speed Packet Radio Systems, EPC UHF Repeater Systems, network routers, data conversion utilities receiving everything from ATC frequency usage to international hazard bulletins, to ultra-top-secret military communication traffic flows, policy development document version control systems, along with a generous sprinkling of partially-implemented or abandoned Lotus Notes applications, intranets, Web servers and firewalls added for good measure.

<sup>13</sup>James L. Cash Jr.; Robert G. Eccles; Nitin Nohria; Richard L. Noland, Building the Information-Age Organization: Structure, Control, and Information Technologies (Boston, Massachusetts: Richard D. Irwin; 1994), p. 160 (emphasis added)

[...]
